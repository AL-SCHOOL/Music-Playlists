# About
This is an Open-Source verison of my Music Playists Website that I use for listening to my music. In this version I removed all of the music that I listen to and changed it so you can insert your own music. The nice thing about this website is that it is quick and easy to use, plus there is hardly any ads.

# Instructions 
**Step 1:** Go into "index.html" and scroll down to the playlists. \
**Step 2:** Go onto YouTube/Spotify and find the embeded code under the share button. \
**Step 3:** Copy *only* the link inside of the embaded code and paste it in the marked location for the playlists. \
**Step 4:** Create/Find a image for the buttons that matches your playlist (Photo must have a 1:1 ratio). \
**Step 5:** Add the photo into the photos folder and copy the path. \
**Step 6:** Go back into "index.html" and paste the path under the marked location for the navigation buttons. \
**Step 7:** Go into "index.js" and change the title names for each of the playlists in the marked locations. \
**Step 8:** Test the code to make sure everything was done correctly. \
**Step 9:** That is it!
