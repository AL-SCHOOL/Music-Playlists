function home() {
  document.getElementById("title").innerHTML = "Home";
  document.getElementById("homepage").style.display = "block";
  document.getElementById("bandPlaylist").style.display = "none";
  document.getElementById("pokemonPlaylist").style.display = "none";
  document.getElementById("marioLuigiPlaylist").style.display = "none";
  document.getElementById("fridayNightPlaylist").style.display = "none";
  document.getElementById("personalPlaylist").style.display = "none";
  document.getElementById("undertalePlaylist").style.display = "none";
}

function playlist1() {
  document.getElementById("title").innerHTML = "*Title for First Playlist*";
  document.getElementById("homepage").style.display = "none";
  document.getElementById("bandPlaylist").style.display = "block";
  document.getElementById("pokemonPlaylist").style.display = "none";
  document.getElementById("marioLuigiPlaylist").style.display = "none";
  document.getElementById("fridayNightPlaylist").style.display = "none";
  document.getElementById("personalPlaylist").style.display = "none";
  document.getElementById("undertalePlaylist").style.display = "none";
}

function playlist2() {
  document.getElementById("title").innerHTML = "*Title for Second Playlist*";
  document.getElementById("homepage").style.display = "none";
  document.getElementById("bandPlaylist").style.display = "none";
  document.getElementById("pokemonPlaylist").style.display = "block";
  document.getElementById("marioLuigiPlaylist").style.display = "none";
  document.getElementById("fridayNightPlaylist").style.display = "none";
  document.getElementById("personalPlaylist").style.display = "none";
  document.getElementById("undertalePlaylist").style.display = "none";
}

function playlist3() {
  document.getElementById("title").innerHTML = "*Title for Third Playlist*";
  document.getElementById("homepage").style.display = "none";
  document.getElementById("bandPlaylist").style.display = "none";
  document.getElementById("pokemonPlaylist").style.display = "none";
  document.getElementById("marioLuigiPlaylist").style.display = "block";
  document.getElementById("fridayNightPlaylist").style.display = "none";
  document.getElementById("personalPlaylist").style.display = "none";
  document.getElementById("undertalePlaylist").style.display = "none";
}

function playlist4() {
  document.getElementById("title").innerHTML = "*Title for Forth Playlist*";
  document.getElementById("homepage").style.display = "none";
  document.getElementById("bandPlaylist").style.display = "none";
  document.getElementById("pokemonPlaylist").style.display = "none";
  document.getElementById("marioLuigiPlaylist").style.display = "none";
  document.getElementById("fridayNightPlaylist").style.display = "block";
  document.getElementById("personalPlaylist").style.display = "none";
  document.getElementById("undertalePlaylist").style.display = "none";
}

function playlist5() {
  document.getElementById("title").innerHTML = "*Title for Fifth Playlist*";
  document.getElementById("homepage").style.display = "none";
  document.getElementById("bandPlaylist").style.display = "none";
  document.getElementById("pokemonPlaylist").style.display = "none";
  document.getElementById("marioLuigiPlaylist").style.display = "none";
  document.getElementById("fridayNightPlaylist").style.display = "none";
  document.getElementById("personalPlaylist").style.display = "block";
  document.getElementById("undertalePlaylist").style.display = "none";
}

home();
